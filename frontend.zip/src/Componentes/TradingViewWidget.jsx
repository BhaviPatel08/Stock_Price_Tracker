import React, { useEffect, useRef, memo } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../Stylesheet/TradingViewWidget.css'

function TradingViewWidget({ symbol }) {
    const navigate = useNavigate();
    const singleQuoteContainer = useRef();
    const advancedChartContainer = useRef();

    // Function to add stock to watchlist
    const handleAddToWatchlist = async () => {
        try {
            // Send the symbol in the request body
            const response = await axios.post(`http://localhost:8000/api/user/watchlist/add`, 
                { symbol } // Send symbol in the request body
            );
            // Navigate to the watchlist page with the symbol as a parameter
            navigate(`/watchlist/${symbol}`);
        } catch (error) {
            if (error.response) {
                console.error('Error adding stock to watchlist:', error.response.data.message);
            } else {
                console.error('Error adding stock to watchlist:', error.message);
            }
        }
    };
    

    useEffect(() => {
        // Single Quote Widget
        const singleQuoteScript = document.createElement('script');
        singleQuoteScript.src = 'https://s3.tradingview.com/external-embedding/embed-widget-single-quote.js';
        singleQuoteScript.async = true;
        singleQuoteScript.innerHTML = JSON.stringify({
            symbol: symbol || 'NASDAQ:AAPL',
            width: 350,
            isTransparent: true,
            colorTheme: 'dark',
            locale: 'en',
        });
        singleQuoteContainer.current.innerHTML = ''; // Clear previous widget
        singleQuoteContainer.current.appendChild(singleQuoteScript);

        // Advanced Chart Widget
        const advancedChartScript = document.createElement('script');
        advancedChartScript.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
        advancedChartScript.type = 'text/javascript';
        advancedChartScript.async = true;
        advancedChartScript.innerHTML = `
        {
          "autosize": true,
          "symbol": "${symbol || 'NASDAQ:AAPL'}",
          "interval": "D",
          "timezone": "Etc/UTC",
          "theme": "light",
          "style": "3",
          "hide_top_toolbar": true,
          "save_image": false,
          "support_host": "https://www.tradingview.com"
        }`;
        advancedChartContainer.current.innerHTML = ''; // Clear previous widget
        advancedChartContainer.current.appendChild(advancedChartScript);
    }, [symbol]);

    return (
        <>
            {/* Single Quote Widget */}
            <div className='space'></div>
            <div className="tradingview-widget-container my-widget" ref={singleQuoteContainer}>
                <div className="tradingview-widget-container__widget"></div>
                <div className="tradingview-widget-copyright">
                    <a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank">
                        <span className="blue-text">Track all markets on TradingView</span>
                    </a>
                </div>
            </div>

            {/* Advanced Chart Widget */}
            <div className="tradingview-widget-container my-chart" ref={advancedChartContainer}>
                <div className="tradingview-widget-container__widget"></div>
                <div className="tradingview-widget-copyright">
                    <a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank">
                        <span className="blue-text">Track all markets on TradingView</span>
                    </a>
                </div>
            </div>

            {/* Add to Watchlist Button */}
            <div style={{ marginTop: '10px' }}>
                <button onClick={handleAddToWatchlist} style={{ padding: '10px 20px', cursor: 'pointer' }}>
                    Add {symbol || 'NASDAQ:AAPL'} to Watchlist
                </button>
            </div>
            <div className='space2'></div>
        </>
    );
}

export default memo(TradingViewWidget);