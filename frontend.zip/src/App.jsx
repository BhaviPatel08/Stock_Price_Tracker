import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


import './App.css'
import Login from './Pages/Login'
import Signup from './Pages/Signup'
import Home from './Pages/Home'
import Product from './Pages/Product'
import Watchlist from './Pages/Watchlist'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/product/:symbol" element={<Product />} />
        <Route path="/watchlist/:symbol" element={<Watchlist />} />
      </Routes>
    </Router>
  );
}

export default App;