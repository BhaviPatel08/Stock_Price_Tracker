import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();
        
        try {
            const response = await fetch('http://localhost:8000/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
            });

            if (response.ok) {
                const data = await response.json();
                const { token } = data;
                localStorage.setItem('jwtToken', token);
                console.log("Token stored in localStorage:", token);

                window.location.href = "/home"; // Redirect to home
            } else {
                const errorData = await response.json();
                console.error("Login failed:", errorData);
            }
        } catch (error) {
            console.error("An error occurred while logging in:", error);
        }
    };

    return (
        <div>
            <h1>Login</h1>
            <form onSubmit={handleLogin}>
                <div>
                    <label>Username</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter Username..."
                    />
                </div>
                <div>
                    <label>Password</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter Password..."
                    />
                </div>
                <button type="submit">Login</button>
                <p style={{marginTop: "10px"}}>
                Don't have an account? <Link to="/signup">Sign up here</Link> {/* Add a link to Signup */}
            </p>
            </form>
            
        </div>
    );
};

export default Login;
