import React, { useState } from "react";
import { Link } from "react-router-dom";
import '../Stylesheet/Home.css'; // Import the CSS file

const Home = () => {
    const [ticker, setTicker] = useState("");
    const [results, setResults] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:8000/api/data?ticker=${ticker}`, {
                method: 'GET',
            });

            if (!response.ok) {
                throw new Error("Failed to fetch data");
            }

            const data = await response.json();
            console.log(data);
            setResults(data);
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    return (
        <>
            <div className="space"></div>
            <div className="container">
            <h1>Trade IQ</h1>
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        placeholder="Search ticker here..."
                        value={ticker}
                        onChange={(e) => setTicker(e.target.value)}
                    />
                    <button type="submit">Search</button>
                </form>
            </div>
            <div className="results">
                <h2>Results:</h2>
                {results && results.bestMatches && (
                    <div>
                        {results.bestMatches.map((match, index) => (
                            <Link
                                to={`/product/${match["1. symbol"]}`} // Adjust the path as needed
                                key={index}
                                className="result-item" // Apply new CSS class here
                                style={{ textDecoration: 'none' }}
                            >
                                <div className="result-content">
                                    <h3>{match["1. symbol"]}: {match["2. name"]}</h3>
                                    <div className="result-scrollable"> {/* New scrollable div */}
                                        <p>Type: {match["3. type"]}</p>
                                        <p>Region: {match["4. region"]}</p>
                                    </div>
                                    <hr />
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
            <div className="space"></div>
        </>
    );
};

export default Home;
