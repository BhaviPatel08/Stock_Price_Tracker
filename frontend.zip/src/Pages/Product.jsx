import React from 'react';
import { useParams } from 'react-router-dom';
import TradingViewWidget from '../Componentes/TradingViewWidget';

const Product = () => {
    const { symbol } = useParams(); // Retrieve the 'symbol' from the URL

    return (
        <div>
            <h1>Product Details for: {symbol}</h1> {/* Display the symbol */}
            <TradingViewWidget symbol={symbol} />
        </div>
    );
};

export default Product;
