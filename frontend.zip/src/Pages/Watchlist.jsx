import axios from 'axios';
import { useState, useEffect } from 'react';
import '../Stylesheet/Watchlist.css'; // Import the CSS file

const Watchlist = () => {
  const [watchlist, setWatchlist] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchWatchlist = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/user/watchlist/list');
        setWatchlist(response.data.watchlist);
      } catch (error) {
        console.error('Error fetching watchlist:', error);
        setMessage('Error fetching watchlist');
      }
    };

    fetchWatchlist();
  }, []);

  const addStockToWatchlist = async (symbol) => {
    try {
      const response = await axios.post('http://localhost:8000/api/user/watchlist/add', { symbol });
      setMessage(response.data.message);
      setWatchlist(response.data.watchlist);
    } catch (error) {
      console.error('Error adding stock:', error);
      setMessage('Error adding stock');
    }
  };

  const removeStockFromWatchlist = async (symbol) => {
    try {
      const response = await axios.delete(`http://localhost:8000/api/user/watchlist/remove/${symbol}`);
      setMessage(response.data.message);
      setWatchlist(response.data.watchlist);
    } catch (error) {
      console.error('Error removing stock:', error);
      setMessage('Error removing stock');
    }
  };

  return (
  <>
    <h1 className="watchlist-title">My Watchlist</h1>
    <div className="watchlist-container">
      {message && <p className="watchlist-message">{message}</p>}
      {watchlist.length === 0 ? (
        <p className="watchlist-empty">The shared watchlist is empty.</p>
      ) : (
        <ul className="watchlist-list">
          {watchlist.map((stock, index) => (
            <li key={index} className="watchlist-item">
              <p>{stock}</p>
              <button className="remove-button" onClick={() => removeStockFromWatchlist(stock)}>Remove</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  </>
    
  );
};

export default Watchlist;