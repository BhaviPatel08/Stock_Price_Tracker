const express = require('express');
const axios = require('axios');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET; // Use environment variable for secret

// Protected search route
router.get('/', async (req, res) => {
    const ticker = req.query.ticker;
    console.log(ticker)
    if (!ticker) {
        return res.status(400).json({ message: 'Ticker symbol is required' });
    }

    const url = `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${ticker}&apikey=${process.env.KEY_SECRET}`;
    
    try {
        const response = await axios.get(url);
        console.log(response)
        res.json(response.data);
    } catch (err) {
        console.error('Error:', err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router;