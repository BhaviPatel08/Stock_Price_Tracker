const express = require('express');
const SharedWatchlist = require('../models/sharedWatchlistModel'); // Import shared watchlist model
const router = express.Router();

// Add stock to the shared watchlist
router.post('/add', async (req, res) => {
    const { symbol } = req.body; // Get the stock symbol from the request body

    if (!symbol) {
        return res.status(400).json({ message: 'Stock symbol is required' });
    }

    try {
        let watchlist = await SharedWatchlist.findOne();

        // If the shared watchlist doesn't exist, create it
        if (!watchlist) {
            watchlist = new SharedWatchlist();
        }

        if (watchlist.stocks.includes(symbol)) {
            return res.status(400).json({ message: 'Stock already in watchlist' });
        }

        watchlist.stocks.push(symbol); // Add the symbol to the shared watchlist
        await watchlist.save();

        res.status(200).json({ message: 'Stock added to shared watchlist', watchlist: watchlist.stocks });
    } catch (err) {
        console.error('Error adding stock to shared watchlist:', err);
        res.status(500).send('Internal Server Error');
    }
});


// Remove stock from the shared watchlist
router.delete('/remove/:symbol', async (req, res) => {
    const { symbol } = req.params; // Get the stock symbol from the URL

    if (!symbol) {
        return res.status(400).json({ message: 'Stock symbol is required' });
    }

    try {
        const watchlist = await SharedWatchlist.findOne();

        if (!watchlist) {
            return res.status(404).json({ message: 'Shared watchlist not found' });
        }

        const index = watchlist.stocks.indexOf(symbol);
        if (index === -1) {
            return res.status(400).json({ message: 'Stock not found in shared watchlist' });
        }

        watchlist.stocks.splice(index, 1); // Remove the stock from watchlist
        await watchlist.save();

        res.status(200).json({ message: 'Stock removed from shared watchlist', watchlist: watchlist.stocks });
    } catch (err) {
        console.error('Error removing stock from shared watchlist:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Get the shared watchlist
// Get user's watchlist
router.get('/list', async (req, res) => {
    try {
        // Fetch the shared watchlist
        const sharedWatchlist = await SharedWatchlist.findOne();

        if (!sharedWatchlist) {
            return res.status(404).json({ message: 'Watchlist not found' });
        }

        // Return the entire shared watchlist
        res.status(200).json({ watchlist: sharedWatchlist.stocks });
    } catch (err) {
        console.error('Error retrieving watchlist:', err);
        res.status(500).send('Internal Server Error');
    }
});



module.exports = router;