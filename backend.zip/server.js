const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const authRoutes = require('./routes/auth'); // Import your auth routes
const searchRoutes = require('./routes/searchRoutes'); // Ensure this matches the actual file name
const watchlistRoutes = require('./routes/watchlistRoutes'); // Import the watchlist routes
const authMiddleware = require('./middelware/auth.js'); 

dotenv.config(); // Load environment variables

const app = express();
app.use(express.json()); // To parse incoming JSON requests

app.use(cors()); // Enable CORS for all routes

const PORT = process.env.PORT || 8000;

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

// Use authentication routes
app.use('/api/auth', authRoutes);

// Use search routes
app.use('/api/data', searchRoutes);

// Use watchlist routes with authentication middleware
app.use('/api/user/watchlist', watchlistRoutes);

// Error handling middleware (optional, to handle unhandled routes)
app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);
});

app.use((error, req, res, next) => {
    res.status(error.status || 500).json({
        error: {
            message: error.message
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
