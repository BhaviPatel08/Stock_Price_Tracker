const mongoose = require('mongoose');

const watchlistSchema = new mongoose.Schema({
    stocks: { type: [String], required: true } // An array of stock symbols
});

const Watchlist = mongoose.model('Watchlist', watchlistSchema);

module.exports = Watchlist;
